package com.zhidian.ad.service;

public interface AdSearchService {
	public String adSearchHander(String adMessage);
	
	public String adSearchHanderV1(String adMessage);
}
