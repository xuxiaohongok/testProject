package com.zhidian.dsp.constant;


public class RedisConstant {
	
	/** 广告类型 */
	public static final String AD_IMAGE = "ad_image_";
	
	public static final String AD_NATIVE = "ad_native_";
	
}
