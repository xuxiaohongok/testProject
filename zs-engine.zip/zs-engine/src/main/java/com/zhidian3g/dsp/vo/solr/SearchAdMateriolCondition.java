package com.zhidian3g.dsp.vo.solr;

public class SearchAdMateriolCondition {
	
	private String meterialType;
	
	private Integer tLen;
	
	private Integer dLen;
	
	private String imageHW;

	public String getMeterialType() {
		return meterialType;
	}

	public void setMeterialType(String meterialType) {
		this.meterialType = meterialType;
	}

	public Integer gettLen() {
		return tLen;
	}

	public void settLen(Integer tLen) {
		this.tLen = tLen;
	}

	public Integer getdLen() {
		return dLen;
	}

	public void setdLen(Integer dLen) {
		this.dLen = dLen;
	}

	public String getImageHW() {
		return imageHW;
	}

	public void setImageHW(String imageHW) {
		this.imageHW = imageHW;
	}
	
}
